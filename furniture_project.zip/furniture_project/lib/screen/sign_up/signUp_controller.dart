
import 'package:get/get.dart' ;

import '../login_screen/login_screen.dart';

class SignUpController extends GetxController{
void navigation(){
  Get.to(const LoginScreen());
}
}