import 'package:flutter/material.dart';

import 'package:get/get.dart';

import '../../commen/commen_widget.dart';
import '../../utils/assets_res.dart';
import '../../utils/color_res.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(SearchController());
    return Scaffold(
      body: Padding(
        padding:
            EdgeInsets.only(top: h * 0.06, left: w * 0.04, right: w * 0.04),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(
                  Icons.arrow_back_outlined,
                  color: Colors.black,
                ),
                horizontal(width: w * 0.03),
                Expanded(
                  child: TextField(
                    cursorColor: Colors.black,
                    decoration: InputDecoration(
                      contentPadding:
                          EdgeInsets.only(top: h * 0.01, left: w * 0.02),
                      fillColor: ColorRes.grey.withOpacity(0.5),
                      prefixIcon: const Icon(
                        Icons.search,
                        color: ColorRes.textGrey,
                      ),
                      filled: true,
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                              const BorderSide(color: ColorRes.textGrey)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: const BorderSide(
                              color: ColorRes.textGrey, width: 1.5)),
                    ),
                  ),
                ),
                horizontal(width: w * 0.05),
                Container(
                  height: h * 0.06,
                  width: w * 0.12,
                  decoration: BoxDecoration(
                      color: ColorRes.yellow,
                      borderRadius: BorderRadius.circular(10)),
                  child: Image.asset(AssetsRes.dot),
                )
              ],
            ),
            vertical(height: h * 0.03),
            Text(
              'Text'.tr,
              style: const TextStyle(
                  color: Colors.black,
                  fontFamily: "Regular",
                  fontSize: 15,
                  height: 2.5),
            ),
            Text(
              "Text1".tr,
              style: const TextStyle(
                  color: Colors.black,
                  fontFamily: "Regular",
                  fontSize: 15,
                  height: 2.5),
            ),
            Text(
              "Text2".tr,
              style: const TextStyle(
                  color: Colors.black,
                  fontFamily: "Regular",
                  fontSize: 15,
                  height: 2.5),
            ),
            Text(
              "Text3".tr,
              style: const TextStyle(
                  color: Colors.black,
                  fontFamily: "Regular",
                  fontSize: 15,
                  height: 2.5),
            ),
            ElevatedButton(
              onPressed: () {
                Get.updateLocale(
                  const Locale('en'),
                );
              },
              child: const Text("English"),
            ),
            ElevatedButton(
              onPressed: () {
                Get.updateLocale(const Locale('ar'),);
              },
              child: const Text("Arabic"),
            ),
          ],
        ),
      ),
    );
  }
}
