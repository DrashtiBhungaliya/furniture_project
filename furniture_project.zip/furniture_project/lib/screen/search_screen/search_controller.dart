import 'package:furniture_project/lang/arabic.dart';
import 'package:get/get.dart';

import '../../lang/eng.dart';

class Search extends Translations{

  @override
  // TODO: implement keys
  Map<String, Map<String, String>>  keys = {
    "en":eng,
    "ar":arabic,
  };

}