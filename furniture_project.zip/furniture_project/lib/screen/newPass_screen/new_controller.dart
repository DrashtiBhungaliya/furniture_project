import 'package:get/get.dart';

class NewPassController extends GetxController{

}