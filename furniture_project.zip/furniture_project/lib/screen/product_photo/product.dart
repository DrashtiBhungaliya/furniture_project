import 'package:flutter/material.dart';
import 'package:furniture_project/screen/cart_screen/cart_screen.dart';
import 'package:furniture_project/screen/product_photo/photo_controller.dart';

import 'package:get/get.dart';

import '../../commen/commen_widget.dart';
import '../../utils/assets_res.dart';
import '../../utils/color_res.dart';
import '../../utils/string_res.dart';

class ProductPhotoScreen extends StatelessWidget {
  const ProductPhotoScreen({super.key});

  @override
  Widget build(BuildContext context) {
    Get.put(PhotoController());
    return Scaffold(
      appBar: AppBar(automaticallyImplyLeading: false,
        flexibleSpace: Padding(
          padding:
              EdgeInsets.only(left: w * 0.05, top: h * 0.04, right: w * 0.05),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              InkWell(onTap: () => Get.back(),
                  child: const Icon(Icons.arrow_back_outlined)),
              const Text(
                StringRes.photo,
                style: TextStyle(fontFamily: "Avenir", fontSize: 17),
              ),
              const Icon(Icons.favorite_outline)
            ],
          ),
        ),
      ),
      body:GetBuilder<PhotoController>(builder: (controller) => Column(crossAxisAlignment: CrossAxisAlignment.center,
        children: [

          Row(crossAxisAlignment: CrossAxisAlignment.center,mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                  height: h * 0.055,
                  width: w * 0.45,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
                    color: ColorRes.grey,
                  ),
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset(
                        AssetsRes.k1,
                        //height: 30,
                      ),

                      Image.asset(
                        AssetsRes.k2,
                        //height: 30,
                      ),

                      Image.asset(
                        AssetsRes.k3,
                        // height: 30,
                      ),

                      Image.asset(
                        AssetsRes.k4,
                        //height: 30,
                      ),

                    ],
                  )
              ),
              horizontal(width: w*0.02),
              Container(
                height: h * 0.04,
                width: w * 0.08,
                decoration: BoxDecoration(borderRadius: BorderRadius.circular(10),
                  color: ColorRes.grey,
                ),
                child: const Icon(Icons.close),
              )
            ],
          ),
          vertical(height: h*0.015),
          commenContainor(
              height: h*0.4,
              width: w*0.65,
              child: Image.asset(Get.arguments["SImage"])
          ),
          vertical(height: h*0.01),
          Image.asset(AssetsRes.curv),
          vertical(height: h*0.015),
          Card(color: Colors.white,shadowColor: Colors.black.withOpacity(0.5),
            elevation: 5,
            child: Container(
              height: h*0.2,padding: EdgeInsets.only(right: w*0.04,left: w*0.04,top: h*0.015),
              width: w*0.9,
              decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.circular(10),),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      commenText(StringRes.rChair),
                      const Spacer(),
                      const Text("(4.4)",style: TextStyle(color: Colors.black,fontSize: 13),),

                      const Icon(Icons.star,color: ColorRes.yellow,size: 16,),
                    ],
                  ),
                  vertical(height: h*0.003),
                  const Text("Living Room",style: TextStyle(color: ColorRes.textGrey,),),
                  vertical(height: h*0.009),
                  const Row(
                    children: [
                      Text("\$78",style: TextStyle(color: Colors.black,fontSize: 20,fontFamily: "Avenir",),),
                      Spacer(),
                      Text("Details",style: TextStyle(color: Colors.black,fontSize: 16,fontFamily: "Avenir",),),
                    ],
                  ),
                  vertical(height: h*0.009),
                  commenButton("Add to Cart",onTap: () {
                    Get.to(CartScreen(shopCart: const []),);
                  },)
                ],
              ),
            ),
          ),

        ],
      ) ,),
    );
  }
}
