import 'package:get/get.dart';

class PhotoController extends GetxController{

}
