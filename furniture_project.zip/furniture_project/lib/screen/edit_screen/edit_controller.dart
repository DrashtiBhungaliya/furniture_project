import 'package:get/get.dart';

class EditController extends GetxController{

}