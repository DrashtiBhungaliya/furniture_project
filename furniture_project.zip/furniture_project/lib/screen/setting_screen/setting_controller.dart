import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingController extends GetxController {
  RxBool light = false.obs;
  final Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getTheme();
  }

  saveTheme() async {
    SharedPreferences pref = await _prefs;
    pref.setBool('theme', light.value);
  }

  getTheme() async {
    var isLight = _prefs.then((SharedPreferences prefs) {
      return prefs.getBool('theme') ?? true;
    }).obs;
    light.value = await isLight.value;
    Get.changeThemeMode(light.value ? ThemeMode.light : ThemeMode.dark);
  }

  void onChanged(val) {
    light.value = val;
    Get.changeThemeMode(
      light.value ? ThemeMode.light : ThemeMode.dark,
    );
    saveTheme();
  }
}
