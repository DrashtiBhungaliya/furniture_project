import 'package:get/get.dart';

class DoneController extends GetxController{

}