
import 'package:get/get.dart';

import '../sign_up/signup_screen.dart';

class LoginController extends GetxController{
  void navigation(){
    Get.to(()=>SignUpScreen());
  }

}