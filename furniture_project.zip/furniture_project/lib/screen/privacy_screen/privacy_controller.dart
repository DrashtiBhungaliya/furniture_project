import 'package:get/get.dart';

class PrivacyController extends GetxController{

}