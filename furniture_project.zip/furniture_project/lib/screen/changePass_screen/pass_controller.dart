import 'package:get/get.dart';

class ChangePassController extends GetxController{

}