import 'package:flutter/material.dart';

import 'package:furniture_project/screen/fav_screen/fav_controller.dart';
import 'package:get/get.dart';

import '../../utils/assets_res.dart';
import '../../utils/color_res.dart';

class HomeController extends GetxController {

  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
FavController favController = Get.put(FavController());
  int counter = 0;
  List<Map> addCart = [];

  HomeController({required this.addCart});

  List<Map> chairList = [
    {
      "image": AssetsRes.c1,
      "Text": "Dulax Estra",
      "Text2": "4.8",
      "Text3": "\$48"
    },
    {
      "image": AssetsRes.c2,
      "Text": "Redanka Chair",
      "Text2": "4.4",
      "Text3": "\$78"
    },
    {
      "image": AssetsRes.c3,
      "Text": "Istamo Chair",
      "Text2": "4.8",
      "Text3": "\$88"
    },
    {
      "image": AssetsRes.c4,
      "Text": "Lensana Chair",
      "Text2": "4.8",
      "Text3": "\$73"
    },
  ];

  void onTap(int index, context) {
     addCart.add(chairList[index]);
    print(chairList[index]);
    counter++;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content:const Text(
            "Item Added",
          ),
          backgroundColor: ColorRes.yellow,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(15),),),
    );
    update(["Update"]);
  }
  void  onTapLike(Map data){
    favController.onTapLikeButton(data);
    update(["Update"]);
  }


  bool isLike(int index){
    return favController.favoritesList.any((element) => element["image"]==chairList[index]["image"]);
  }

}
