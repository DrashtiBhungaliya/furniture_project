Map<String,String> arabic = {
"Text":"أريكة صفراء",
"Text1":"أريكة الخوص",
"Text2":"كنبة",
"Text3":"أريكة بين باج"
};