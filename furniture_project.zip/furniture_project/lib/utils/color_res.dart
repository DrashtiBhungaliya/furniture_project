import 'package:flutter/material.dart';

class ColorRes{
  static const  yellow = Color(0xffF4C66F);
  static const  darkYellow = Color(0xffF5A629);
  static const  grey = Color(0xffE7ECEF);
  static const  lightGrey = Color(0xffF7F7F7);
  static const  textGrey = Color(0xff91939B);

}